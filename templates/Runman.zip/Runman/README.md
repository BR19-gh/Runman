
<h1 style="text-align: center;">IMPORTANT | مـــــــهــــــم | IMPORTANTE | 重要 | IMPORTANT | 重要的</h1>
<hr style="border-width:5px;">
<br>
<div style="text-align: center; display: flex; flex-wrap: wrap;">
<div style="width: 50%;">
<h2>English</h2>
<h3>Press <code>PLAY_Runman</code> file to run the game</h3>
<h5>TIP: You can move or change the directory of <code>PLAY_Runman</code> file anywhere on your PC</h5>
</div>

<div style="width: 50%;">
<h2 dir="rtl">الــعــربــية</h2>
<h3 dir="rtl">اضغط ملف <code>PLAY_Runman</code> لتشغيل اللعبة</h3>
<h5 dir="rtl">تلميحة: يمكنك نقل ملف <code>PLAY_Runman</code> لأي مكان على جهازك</h5>
</div>

<div style="width: 50%;">
<h2>日本語</h2>
<h3><code>PLAY_Runman</code>ファイルを押してゲームを実行します</h3>
<h5>ヒント：<code>PLAY_Runman</code>ファイルはPCのどこにでも移動できます</h5>
</div>

<div style="width: 50%;">
<h2>Español</h2>
<h3>Presione el archivo <code>PLAY_Runman</code> para ejecutar el juego</h3>
<h5>Consejo: puede mover el archivo <code>PLAY_Runman</code> a cualquier lugar de su PC</h5>
</div>

<div style="width: 50%;">
<h2>Français</h2>
<h3>Appuyez sur le fichier <code>PLAY_Runman</code> pour lancer le jeu</h3>
<h5>CONSEIL : Vous pouvez déplacer le fichier <code>PLAY_Runman</code> n'importe où sur votre PC</h5>
</div>

<div style="width: 50%;">
<h2>简体中文</h2>
<h3>按 <code>PLAY_Runman</code> 开始游戏</h3>
<h5>提示：您可以将 <code>PLAY_Runman</code> 文件移动到 PC 上的任何位置</h5>
</div>
</div>